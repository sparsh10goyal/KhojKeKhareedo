package com.capgemini.bank;

public class SavingAccount_2 extends SavingAccount implements Insurance{
	
	
	
public void getInsuranceNO(int insuranceNO) {
		
	}

	

	public void getInsuranceName(String InsuranceName) {
		// TODO Auto-generated method stub
		
	}

	public void getInsuranceAmount(double InsuranceAmount) {
		
		
	}



	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		
	}
}
