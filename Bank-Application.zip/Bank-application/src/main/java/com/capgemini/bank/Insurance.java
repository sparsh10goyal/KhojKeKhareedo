package com.capgemini.bank;


public interface Insurance {

	 
	  
	  
	    void getInsuranceNO(int insuranceNo);
	    void getInsuranceName(String InsuranceName);
	    void getInsuranceAmount(double InsuranceAmount);
		
	    
	} 
	  
	

