package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
@RequestMapping(value="/employee",method=RequestMethod.GET)
public Employee firstpage() {
	
	Employee emp1=new Employee();
	emp1.setName("Sparsh Goyal");
	emp1.setDesignation("Analyst");
	emp1.setEmpId("abcd");
	emp1.setSalary(50000);
	return emp1;
}
}
