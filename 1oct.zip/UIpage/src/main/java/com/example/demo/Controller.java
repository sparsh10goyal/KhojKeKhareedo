package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Controller{
	@Autowired
    private DiscoveryClient discoveryClient;
    
    
        @PostMapping(value="/signup")
	public ModelAndView signup(@ModelAttribute("users") uiPojo user) {
		
		
		 List<ServiceInstance> instances=discoveryClient.getInstances("DB-Producer");
	        ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
	        String baseUrl=serviceInstance.getUri().toString();
	        baseUrl=baseUrl+"/c";
	        
	        RestTemplate restTemplate=new RestTemplate();
	        uiPojo result=restTemplate.postForObject(baseUrl,user,uiPojo.class);
	
	System.out.println(result.toString());
	return null;
	
	
	}
}
