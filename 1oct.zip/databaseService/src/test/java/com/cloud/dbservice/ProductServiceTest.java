package com.cloud.dbservice;


	import java.util.ArrayList;
	import java.util.List;

	import org.junit.Assert;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.Mockito;
	import org.mockito.junit.MockitoJUnitRunner;

import com.cloud.dbservice.model.Product;
import com.cloud.dbservice.model.User;
import com.cloud.dbservice.resource.ProductRepository;
import com.cloud.dbservice.resource.ProductService;
import com.cloud.dbservice.resource.UserRepository;
import com.cloud.dbservice.resource.UserService;







	@RunWith(MockitoJUnitRunner.class)
	public class ProductServiceTest {
	@InjectMocks
	ProductService registerService;

	@Mock
	ProductRepository registerController;
	
	
	
	
	       
	       @Test
	       public void findByProduct1()
	              {
	    	   Product register2=new Product();
	                     register2.setPname("fans");
	                     Mockito.when(registerService.findByPname("fans")).thenReturn(register2);
	                     Product reg1=registerController.findByPname("fans");
	                     Assert.assertNotNull(reg1);
	                     
	              }
	    
	       
	     
	       }