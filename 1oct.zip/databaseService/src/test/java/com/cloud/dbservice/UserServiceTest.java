package com.cloud.dbservice;


	

	import java.util.ArrayList;
	import java.util.List;

	import org.junit.Assert;
	import org.junit.Test;
	import org.junit.runner.RunWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.Mockito;
	import org.mockito.junit.MockitoJUnitRunner;

import com.cloud.dbservice.model.User;
import com.cloud.dbservice.resource.UserRepository;
import com.cloud.dbservice.resource.UserService;







	@RunWith(MockitoJUnitRunner.class)
	public class UserServiceTest {
	@InjectMocks
	UserService registerService;

	@Mock
	UserRepository registerController;
	
	/*
	@Test
	public void addRegister1() {
		 User register=new User("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	       Mockito.when(UserService.create("pragnya","Abc123@","9876543210","abc@gmail.com","free")).thenReturn(register);
	       User reg1=registerController.save("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	              
	              //System.out.println(reg1);
	              Assert.assertNotNull(reg1);
	           
	}  */   
	@Test
	public void addRegister2() {
		 User register=new User("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	       Mockito.when(registerService.create(register)).thenReturn(register);
	       User reg1=registerController.create("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	       
	              //System.out.println(reg1);
	              Assert.assertNotNull(reg1);
	              }
	           
	@Test
	       public void getAllProductTest_1()
	       {
	              List< User> regList=new ArrayList< User>();
	              User register=new  User("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	              regList.add(register);
	              register=new  User("pragnya","Abc123@","9876543210","abc@gmail.com","free");
	              regList.add(register);
	              Mockito.when(registerService.findAll()).thenReturn(regList);
	              List< User> registers=registerController.findAll();
	              Assert.assertEquals(regList.size(),registers.size());

	} 

	      
	       
	       @Test
	       public void findByPhone1()
	              {
	                   User register2=new User();
	                     register2.setPhone("9036851911");
	                     Mockito.when(registerService.findByPhone("9036851911")).thenReturn(register2);
	                     User reg1=registerController.findByPhone("9036851911");
	                     Assert.assertNotNull(reg1);
	                     
	              }
	    
	       
	       @Test
	       public void findByEmail1()
	              {
	                     User register2=new User();
	                     register2.setEmail("prabhu@gmail.com");
	                     Mockito.when(registerService.findByEmail("prabhu@gmail.com")).thenReturn(register2);
	                  User reg1=registerController.findByEmail("prabhu@gmail.com");
	                     Assert.assertNotNull(reg1);
	                     
	     
	             
	}
	       }