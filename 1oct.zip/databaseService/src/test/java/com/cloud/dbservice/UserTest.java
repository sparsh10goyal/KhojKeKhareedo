package com.cloud.dbservice;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.junit.MockitoJUnitRunner;

import com.cloud.dbservice.model.User;


public class UserTest {
	
	
	
	    @Test
	    public void gettersSettersTest()
	    {
	                    //default constructor
	                User register=new User();
	                    //setters
	                    register.setName("pragnya");
	                    register.setAddress("Mobile");
	                    register.setPassword("Mobiles");
	                    register.setEmail("prabhu@gmail.com");
	                    register.setPhone("9036851911");
	                    
	                   // register.setUserType("free");
	                   // register.setActivated(false);
	                    //getters
	                   
	                    
	                    Assert.assertEquals("pragnya", register.getName());
	                    Assert.assertEquals("Mobile", register.getAddress());
	                    Assert.assertEquals("Mobiles", register.getPassword());
	                    Assert.assertEquals("prabhu@gmail.com", register.getEmail());
	                    Assert.assertEquals("9036851911", register.getPhone());
	                   // Assert.assertEquals("123", register.getUserId());
	                   // Assert.assertEquals("free", register.getUserType());
	                   // Assert.assertEquals(false, register.isActivated());
	    }
	    
	
	}

