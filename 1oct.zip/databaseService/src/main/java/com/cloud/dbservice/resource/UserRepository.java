package com.cloud.dbservice.resource;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cloud.dbservice.model.User;

@Repository
public interface UserRepository extends MongoRepository<User, String> {
	public User findByEmail(String email);
	public User findByPhone(String phone);
	public User findByNameAndPassword(String name, String password);
	public User findByEmailAndPassword(String email, String password);
	public List<User> findByAddress(String name);
	public User saveAll();
	public User create(String name, String password, String phone, String email, String address);
	
}