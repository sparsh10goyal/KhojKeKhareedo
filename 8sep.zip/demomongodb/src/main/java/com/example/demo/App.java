package com.example.demo;


	import java.util.logging.Level;
	import java.util.logging.Logger;
	 
	import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
	import com.mongodb.MongoClientURI;
	import com.mongodb.client.MongoCollection;
	import com.mongodb.client.MongoCursor;
	import com.mongodb.client.MongoDatabase;
	import com.mongodb.client.model.IndexOptions;
	 
	 
	public class App {
	    public static void main(String[] args) {
	        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
	        mongoLogger.setLevel(Level.SEVERE);
	       
	        
	        
	        App app = new App();
	      
	        System.out.println("1] query = fans ");
	        app.fullTextSearch("fans");
	        System.out.println("-------------------------------------------------------------------------");
	 
	       System.out.println("2] query = Sofa");
	       app.fullTextSearch("Sofa");
	       System.out.println("-------------------------------------------------------------------------");
	 
	        System.out.println("3] query = \"Cars\"");
	        app.fullTextSearch("Cars");
	        System.out.println("-------------------------------------------------------------------------");
	    }
	    
	    
public void fullTextSearch(String query) {
	 
	        MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
	       MongoDatabase database = mongoClient.getDatabase("user");
	        MongoCollection<Document> collection = database.getCollection("products");
	      
	        try {
	            MongoCursor<Document> cursor = null;
	            cursor = collection.find(new Document("$text", new Document("$search", query))).iterator();
	 
	            while (cursor.hasNext()) {
	                Document products = cursor.next();
	                System.out.println(products);
	            }
	 
	            cursor.close();
	 
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            mongoClient.close();
	        }
	 
	    }
	 
	}

