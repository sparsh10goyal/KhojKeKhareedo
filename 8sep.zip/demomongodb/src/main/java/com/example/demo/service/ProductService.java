package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository prepo;
	
	public Product addProduct(int n,String pname, String pcategory, double price, String pdesc, String uname, String uphone, String uemail) {
		return prepo.save(new Product(n,pname,pcategory,price,pdesc,uname,uphone,uemail));
		
	}

	public Product findByPname(String pname) {
		// TODO Auto-generated method stub
		return prepo.findByPname(pname);
	}
	
	public List<Product> findByPcategory(String pcategory) {
		// TODO Auto-generated method stub
		return prepo.findByPcategory(pcategory);
	}
	
	//public List<Product> searchResults(String pname){
		
		 //Query query=new Query();
		// Query.addCriteria(Criteria.where("))
		 
		//return prepo.searchResults(pname);
	//}
	
}
