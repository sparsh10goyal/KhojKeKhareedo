package com.example.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Product;
import com.example.demo.model.User;

public interface SearchRepository extends MongoRepository<Product, String> {

	public Product findByPname(String pname);

}
