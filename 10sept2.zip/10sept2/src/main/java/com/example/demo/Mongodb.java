package com.example.demo;
 
import java.util.logging.Level;
import java.util.logging.Logger;
 
import org.bson.Document;

import com.example.demo.controllers.ProductController;
import com.example.demo.service.ProductService;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
 
 
public class Mongodb extends ProductService{
    public static void main(String[] args) {
        Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        mongoLogger.setLevel(Level.SEVERE);
 
        //Mongodb app = new Mongodb();
 /*       app.insert();
        System.out.println("1] query = coffee , caseSensitive = false, diacriticSensitive = false");
        app.fullTextSearch("coffee", false, false);
        System.out.println("-------------------------------------------------------------------------");
 
        System.out.println("2] query = bake coffee cake , caseSensitive = false, diacriticSensitive = false");
        app.fullTextSearch("bake coffee cake", false, false);
        System.out.println("-------------------------------------------------------------------------");
 
 
        System.out.println("3] query = \"coffee shop\" , caseSensitive = false, diacriticSensitive = false");
        app.fullTextSearch("\"coffee shop\"", false, false);
        System.out.println("-------------------------------------------------------------------------");
 
 
        System.out.println("4] query = coffee -shop , caseSensitive = false, diacriticSensitive = false");
        app.fullTextSearch("coffee -shop", false, false);
        System.out.println("-------------------------------------------------------------------------");
 
 
        System.out.println("5] query = Coffee , caseSensitive = true , diacriticSensitive = false");
        app.fullTextSearch("Coffee", true, false);
        System.out.println("-------------------------------------------------------------------------");
 
 
        System.out.println("6] query = CAFÉ , caseSensitive = false , diacriticSensitive = true");
        app.fullTextSearch("CAFÉ", false, true);
        System.out.println("-------------------------------------------------------------------------");
 */
    }
 
 
 
    public void fullTextSearch(String query, boolean caseSensitive, boolean diacriticSensitive) {
 
        MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
        MongoDatabase database = mongoClient.getDatabase("user");
        MongoCollection<Document> collection = database.getCollection("products");
 
        try {
            MongoCursor<Document> cursor = null;
            cursor = collection.find(new Document("$text", new Document("$search", query).append("$caseSensitive", new Boolean(caseSensitive)).append("$diacriticSensitive", new Boolean(diacriticSensitive)))).iterator();
 
            while (cursor.hasNext()) {
                Document article = cursor.next();
                System.out.println();
            }
 
            cursor.close();
 
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            mongoClient.close();
        }
 
    }
 
}