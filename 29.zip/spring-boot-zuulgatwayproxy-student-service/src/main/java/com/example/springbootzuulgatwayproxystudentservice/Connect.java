package com.example.springbootzuulgatwayproxystudentservice;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@SpringBootApplication
public class Connect {
	
	@RequestMapping(value="/signup1", method=RequestMethod.GET)
	public ModelAndView signup() {
		ModelAndView mav = new ModelAndView("/ui/signup");
		return mav;
	}


}
