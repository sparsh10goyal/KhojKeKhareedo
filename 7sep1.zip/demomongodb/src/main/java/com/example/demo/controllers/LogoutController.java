package com.example.demo.controllers;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.example.demo.service.UserService;



@RestController

public class LogoutController {
	
	@Autowired
	private UserService service;
	

	@RequestMapping(value="/logout", method = RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("name") String name, @ModelAttribute("password") String password,Model model ) {
	
		if(service.findByNameAndPassword(name, password) != null) {
			ModelAndView mav = new ModelAndView(); 
			
			mav.setViewName("index");
			
			
			return mav;
		}
		else {
			 
			ModelAndView mav1 = new ModelAndView("signin");
			model.addAttribute("signinerror", "Invalid Login Credentials");
			return mav1;
		}
		
	}
}
