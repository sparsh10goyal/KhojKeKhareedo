package com.cloud.dbservice.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection= "products")
public class Product {
	
	@Id
	String pid;
	String pname;
	String pcategory;
	double price;
	String pdesc;
	String uname;
	String uphone;
	String uemail;
	int n;
	String brand;
	int year;
	public Product(int n,String pname, String pcategory, double price, String pdesc, String uname, String uphone,
			String uemail,String brand,int year) {
		
		this.pname = pname;
		this.pcategory = pcategory;
		this.price = price;
		this.pdesc = pdesc;
		this.uname = uname;
		this.uphone = uphone;
		this.uemail = uemail;
		this.n=n;
		this.brand=brand;
		this.year=year;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * @return the pname
	 */
	public String getPname() {
		return pname;
	}
	/**
	 * @param pname the pname to set
	 */
	public void setPname(String pname) {
		this.pname = pname;
	}
	/**
	 * @return the pcategory
	 */
	public String getPcategory() {
		return pcategory;
	}
	/**
	 * @param pcategory the pcategory to set
	 */
	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the pdesc
	 */
	public String getPdesc() {
		return pdesc;
	}
	/**
	 * @param pdesc the pdesc to set
	 */
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	/**
	 * @return the uname
	 */
	public String getUname() {
		return uname;
	}
	/**
	 * @param uname the uname to set
	 */
	public void setUname(String uname) {
		this.uname = uname;
	}
	/**
	 * @return the uphone
	 */
	public String getUphone() {
		return uphone;
	}
	/**
	 * @param uphone the uphone to set
	 */
	public void setUphone(String uphone) {
		this.uphone = uphone;
	}
	/**
	 * @return the uemail
	 */
	public String getUemail() {
		return uemail;
	}
	public int getN() {
		return n;
	}
	/**
	 * @param uemail the uemail to set
	 */
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pcategory=" + pcategory + ", price=" + price + ", pdesc="
				+ pdesc + ", uname=" + uname + ", uphone=" + uphone + ", uemail=" + uemail + "]";
	}
	public void setN(int n) {
		this.n = n;
	}
	
		
	

}
