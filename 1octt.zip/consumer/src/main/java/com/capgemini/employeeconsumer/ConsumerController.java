package com.capgemini.employeeconsumer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;

@RestController
public class ConsumerController {
                @Autowired
                private DiscoveryClient discoveryClient;
                @Autowired
            	private LoadBalancerClient loadBalancer;
                
               
                @GetMapping("/signin")
                public String getOdi()
                {
//                                List<ServiceInstance> instances=discoveryClient.getInstances("");
                                ServiceInstance si=loadBalancer.choose("ui");
                                System.out.println(si.getUri());
//                                ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
                                String baseUrl=si.getUri().toString()+"/signin";
//                                String baseUrl=serviceInstance.getUri().toString()+"/all";
                                RestTemplate restTemplate=new RestTemplate();
                                ResponseEntity<String> response=null;
                                try {
                                                response=restTemplate.exchange(baseUrl,HttpMethod.GET, getHeaders(), String.class);
                                                                                
                                }
                                catch (Exception ex)
                                {
                                                System.out.println(response.getBody());
                                                
                                                
                                }
                                
                                return response.getBody();
                }
                public HttpEntity<?> getHeaders()
                {
                                HttpHeaders headers=new HttpHeaders();
                                headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
                                return new HttpEntity<>(headers);
                                
                }
                
                
                @PostMapping("/")
                public String getOdi8()
                {
//                                List<ServiceInstance> instances=discoveryClient.getInstances("");
                                ServiceInstance si=loadBalancer.choose("db");
                                System.out.println(si.getUri());
//                                ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
                                String baseUrl=si.getUri().toString()+"/";
//                                String baseUrl=serviceInstance.getUri().toString()+"/all";
                                RestTemplate restTemplate=new RestTemplate();
                                ResponseEntity<String> response=null;
                                try {
                                                response=restTemplate.exchange(baseUrl,HttpMethod.GET, getHeaders8(), String.class);
                                                                                
                                }
                                catch (Exception ex)
                                {
                                                System.out.println(response.getBody());
                                                
                                                
                                }
                                
                                return response.getBody();
                }
                public HttpEntity<?> getHeaders8()
                {
                                HttpHeaders headers=new HttpHeaders();
                                headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
                                return new HttpEntity<>(headers);
                                
                }
                
                
                
                
                
                @GetMapping("/signup")
                public String getOdi1()
                {
//                                List<ServiceInstance> instances=discoveryClient.getInstances("");
                                ServiceInstance si=loadBalancer.choose("ui");
                                System.out.println(si.getUri());
//                                ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
                                String baseUrl=si.getUri().toString()+"/signup";
//                                String baseUrl=serviceInstance.getUri().toString()+"/all";
                                RestTemplate restTemplate=new RestTemplate();
                                ResponseEntity<String> response=null;
                                try {
                                                response=restTemplate.exchange(baseUrl,HttpMethod.GET, getHeaders1(), String.class);
                                                                                
                                }
                                catch (Exception ex)
                                {
                                                System.out.println(response.getBody());
                                                
                                                
                                }
                                
                                return response.getBody();
                }
                public HttpEntity<?> getHeaders1()
                {
                                HttpHeaders headers=new HttpHeaders();
                                headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
                                return new HttpEntity<>(headers);
                                
                }


@GetMapping("/abc")
public String getOdi2()
{
//                List<ServiceInstance> instances=discoveryClient.getInstances("");
                ServiceInstance si=loadBalancer.choose("ui");
                System.out.println(si.getUri());
//                ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
                String baseUrl=si.getUri().toString()+"/index";
//                String baseUrl=serviceInstance.getUri().toString()+"/all";
                RestTemplate restTemplate=new RestTemplate();
                ResponseEntity<String> response=null;
                try {
                                response=restTemplate.exchange(baseUrl,HttpMethod.GET, getHeaders2(), String.class);
                                                                
                }
                catch (Exception ex)
                {
                                System.out.println(response.getBody());
                                
                                
                }
                
                return response.getBody();
}
public HttpEntity<?> getHeaders2()
{
                HttpHeaders headers=new HttpHeaders();
                headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
                return new HttpEntity<>(headers);
                
}
}