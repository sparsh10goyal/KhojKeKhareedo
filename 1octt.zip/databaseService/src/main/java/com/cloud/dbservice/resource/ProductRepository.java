package com.cloud.dbservice.resource;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cloud.dbservice.model.Product;
import com.cloud.dbservice.model.User;
@Repository
public interface ProductRepository extends MongoRepository<Product, String> {

	public Product findByPname(String pname);
	public List<Product> findByPcategory(String electronics);
}
