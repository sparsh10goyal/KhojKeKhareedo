package com.cloud.dbservice.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.dbservice.model.Product;
import com.cloud.dbservice.model.User;
@RestController
@Service
public class UserService {

	
	@Autowired
	
	private UserRepository repo;
	
	public User create(String name, String password, String phone, String email, String address) {
		return repo.save(new User(name,password,phone,email,address));
		
	}
	@GetMapping("/")
	public List<User> getall()
	{
		
		
		return repo.findAll();
		
		
	}
	public User findByEmail(String email) {
		return repo.findByEmail(email);
	}
	
	public User findByPhone(String phone) {
		return repo.findByPhone(phone);
	}
	
	public User findByNameAndPassword(String name, String password) {
		return repo.findByNameAndPassword(name,password);
	}
	
	
}
