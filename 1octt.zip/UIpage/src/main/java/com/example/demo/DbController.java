package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;





@Controller
public class DbController {

	
	@Autowired
    private DiscoveryClient discoveryClient;
    
    @PostMapping("/signup")
    public ModelAndView signup(@ModelAttribute("user") User user) {
    
        List<ServiceInstance> instances=discoveryClient.getInstances("db");
        ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
        String baseUrl=serviceInstance.getUri().toString()+"/signup";
        RestTemplate restTemplate=new RestTemplate();
        User result=restTemplate.postForObject(baseUrl, user, User.class);
        System.out.println(result.toString());
        return null;
}
}